package com.capg.controller;

import java.security.NoSuchAlgorithmException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capg.bean.Customer;
import com.capg.bean.Email;
import com.capg.bean.Merchant;
import com.capg.bean.Product;
import com.capg.bean.ThirdPartyMerchant;
import com.capg.bean.WishItem;
import com.capg.service.CapgService;

@CrossOrigin("*")
@RestController
public class CapgController {

	@Autowired
	CapgService capgService;

	@PostMapping("/register")
	public void registerCustomer(@RequestBody Customer customer) {
		capgService.registerCustomer(customer);
	}

	@PostMapping("/addWish/{custId}")
	public void addCustomerWish(@PathVariable String custId, @RequestBody WishItem wish) {
		capgService.addCustomerWish(custId, wish);
	}

	@RequestMapping("/ecommerce/185755/showCust")
	public List<Customer> showCustomers() {
		return capgService.showCustomers();
	}

	@RequestMapping("/ecommerce/185755/showProd")
	public List<Product> showProducts() {
		return capgService.showProducts();
	}

	@RequestMapping("/ecommerce/185755/showMerch")
	public List<Merchant> showMerchants() {
		return capgService.showMerchants();
	}

	@RequestMapping("/ecommerce/185755/showEmail")
	public List<Email> showEmails() {
		return capgService.showEmails();
	}

	@RequestMapping("/ecommerce/185755/pendingMerchants/{isValid}")
	public List<Merchant> pendingMerchants(@PathVariable("isValid") String isValid) {
		return capgService.pendingMerchants(isValid);
	}

	@PutMapping("/ecommerce/185755/acceptMerchants/{MerId}/{isValid}")
	public List<Merchant> acceptMerchants(@PathVariable("MerId") String MerId,
			@PathVariable("isValid") String isValid) {
		return capgService.acceptMerchants(MerId, isValid);
	}

	@PutMapping("/ecommerce/185755/denyMerchants/{MerId}/{isValid}")
	public List<Merchant> denyMerchants(@PathVariable("MerId") String MerId, @PathVariable("isValid") String isValid) {
		return capgService.denyMerchants(MerId, isValid);
	}

//	@RequestMapping(value = "ecommerce/185697/registerMerchant/{password}", method = RequestMethod.POST)
//	public String registerMerchant(@RequestBody Merchant merchant, @PathVariable String password)
//			throws NoSuchAlgorithmException {
//		String password1 = capgService.encryptPassword(password);
//		return capgService.registerMerchant(merchant, password1);
//	}
	
	@PostMapping("registerMerchant/{password}")
	public void registerMerchant(@RequestBody Merchant merchant, @PathVariable("password") String pass) {
		capgService.registerMerchant(merchant, pass);
	}
	
	@PostMapping("registerTPMerchant/{password}")
	public void registerTPMerchant(@RequestBody ThirdPartyMerchant merchant, @PathVariable("password") String pass) {
		capgService.registerTPMerchant(merchant, pass);
	}


//	@RequestMapping(value = "ecommerce/185697/registerTPMerchant/{password}", method = RequestMethod.POST)
//	public String registerTPMerchant(@RequestBody ThirdPartyMerchant merchant, @PathVariable String password)
//			throws NoSuchAlgorithmException {
//		String password1 = capgService.encryptPassword(password);
//		return capgService.registerTPMerchant(merchant, password1);
//	}

	@RequestMapping(value = "ecommerce/185697/deletemerchant/{merId}", method = RequestMethod.DELETE)
	public void deleteMerchant(@PathVariable("merId") String merId) {
		capgService.deleteMerchant(merId);
	}

	@RequestMapping(value = "ecommerce/185697/invitemerchant", method = RequestMethod.POST)
	public void inviteMerchant(@RequestBody ThirdPartyMerchant inviteThirdParty) {
		capgService.inviteThirdParty(inviteThirdParty);
	}

	@PostMapping("ecommerce/185697/send")
	public void sendMail(@RequestBody Email maildata) {
		capgService.sendMail(maildata);
	}

	@GetMapping("ecommerce/185697/getmymail")
	public List<Email> getMyMails() {
		return capgService.getMyMails();
	}

	@GetMapping("ecommerce/185697/getInbox")
	public List<Email> getInbox() {
		return capgService.getInbox();
	}

	@RequestMapping("/ecommerce/185755/totalRevenue")
	public double totalRevenue() {
		return capgService.totalRevenue();
	}

}
