import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { CategoryReport } from '../app/category-report';
import { MerchantReport } from '../app/merchant-report';

import { Observable } from 'rxjs';
import { Customer } from './Customer';
import { Merchant } from './Merchant';
import { Email } from './email';
import { ThirdParty } from './third-party';
import { Coupon } from './coupon';
import { OrderedItem } from './ordered-item';
import { Product } from './Product';
import { Report } from './report';






@Injectable({
  providedIn: 'root'
})
export class AdminServiceService {

  customer: Customer[];
  merchant: Merchant[];
  tpmerchant: ThirdParty[];
  email: Email[];
  private fromAdminDD = false;
  private fromAdminTP = false;
  private inviteTP = false;

  private baseUrl = 'http://localhost:8082/ecommerce/';
  constructor(private http: HttpClient) { }

  /*
  * To get report of Order Status
  */
  public getReport(): Observable<Report> {
    return this.http.get<Report>("http://localhost:4202/getReport")
  }

  /*
  * To get report of Category of Products Sold
  */
  public getCategoryReport(): Observable<CategoryReport> {
    return this.http.get<CategoryReport>("http://localhost:4202/getCategoryReport")
  }

  /*
  * To get report of Merchant of Products Sold
  */
  public getMerchantReport(): Observable<MerchantReport> {
    return this.http.get<MerchantReport>("http://localhost:4202/getMerchantReport")
  }

  public displayOrderedItems(): Observable<OrderedItem[]> {
    return this.http.get<OrderedItem[]>(this.baseUrl + '186125/getOrderedItems')
  }


  public setFromAdminDD(fromAdminDD: boolean) {
    this.fromAdminDD = fromAdminDD;
  }

  public getFromAdminDD() {
    return this.fromAdminDD;
  }
  public setFromAdminTP(fromAdminTP: boolean) {
    this.fromAdminTP = fromAdminTP;
  }

  public getFromAdminTP() {
    return this.fromAdminTP;
  }
  public setInviteTP(inviteTP: boolean) {
    this.inviteTP = inviteTP;
  }

  public getInviteTP() {
    return this.inviteTP;
  }

  showCustomers(): Observable<Customer[]> {
    console.log("http://localhost:8082/ecommerce/185755/showCust");
    return this.http.get<Customer[]>(this.baseUrl + "185755/showCust");
  }

  showMerchants(): Observable<Merchant[]> {
    console.log("http://localhost:8082/ecommerce/185755/showMerch");
    return this.http.get<Merchant[]>(this.baseUrl + "185755/showMerch");
  }

  pendingRequests(): Observable<Merchant[]> {

    console.log("http://localhost:8082/ecommerce/185755/");
    return this.http.get<Merchant[]>(this.baseUrl + "185755/pendingMerchants/PENDING");
  }

  acceptMerchant(merId: string): Observable<Merchant[]> {
    console.log(merId);
    return this.http.put<Merchant[]>(this.baseUrl + "185755/acceptMerchants/" + merId + "/PENDING", "")
  }

  denyMerchant(merId: string): Observable<Merchant[]> {
    console.log(merId);
    return this.http.put<Merchant[]>(this.baseUrl + "185755/denyMerchants/" + merId + "/PENDING", "")

  }

  totalRevenue(): Observable<number> {
    return this.http.get<number>("http://localhost:4202/getTotalRevenue");
  }

  public addMerchant(merchant: Merchant, password: String): Observable<Merchant> {
    console.log(merchant);
    return this.http.post<Merchant>('http://localhost:8082/registerMerchant/' + password, merchant)
  }

  public addTPMerchant(merchant: Merchant, password: String): Observable<Merchant> {
    console.log(merchant);
    return this.http.post<Merchant>('http://localhost:8082/registerTPMerchant/' + password, merchant)
  }
  // public addMerchant(merchant:Merchant,password:string) :Observable<Merchant>{
  //   return this.http.post<Merchant>(this.baseUrl+'185697/registerMerchant/'+password,merchant);

  // };
  // public addTPMerchant(tpmerchant:ThirdParty,password:string) :Observable<ThirdParty>{
  //   return this.http.post<ThirdParty>(this.baseUrl+'185697/registerTPMerchant/'+password,tpmerchant);

  // };
  public deleteMerchant(merId: string) {
    return this.http.delete<Merchant>(this.baseUrl + '185697/deletemerchant/' + merId);

  };
  public inviteMerchant(thirdParty: ThirdParty) {
    return this.http.post<ThirdParty>(this.baseUrl + '185697/invitemerchant', thirdParty);
  };
  public sendMail(mail: Email) {
    return this.http.post<Email>(this.baseUrl + "185697/send", mail);
  };
  public getMail() {
    return this.http.get<Email>(this.baseUrl + "185697/getmymail");
  }
  public getInbox() {
    return this.http.get<Email>(this.baseUrl + "185697/getInbox");
  }
  public getAllCoupons() {

    return this.http.get<Coupon[]>(this.baseUrl + "185753/getCoupon");
  }
  public generateCoupon(coupon: Coupon): Observable<Coupon> {

    return this.http.post<Coupon>(this.baseUrl + "185753/generateCoupon", coupon)
  }
  showAllOrderedProducts(): Observable<OrderedItem[]> {
    return this.http.get<OrderedItem[]>(this.baseUrl + "185684/PLD/DISP");
  }

  getProducts(): Observable<OrderedItem[]> {

    return this.http.get<OrderedItem[]>(this.baseUrl + "185684/DISP/PLD");
  }

  //Purpose:This is for Displaying all placed  products
  showPlacedProducts(): Observable<OrderedItem[]> {

    return this.http.get<OrderedItem[]>(this.baseUrl + "185684/placedproducts");
  }

  //Purpose:This is for Displaying all dispatched products
  showDispatchedProducts(): Observable<OrderedItem[]> {
    return this.http.get<OrderedItem[]>(this.baseUrl + "185684/dispatchedproducts");
  }
  //Purpose:This is for updating placed  product to dispatched product
  updatePld(productOrdId: string, productOrdStatus: string): Observable<OrderedItem[]> {

    return this.http.get<OrderedItem[]>(this.baseUrl + "185684/updatePlacedProducts/" + productOrdId + '/' + productOrdStatus);
  }

  //Purpose:This is for updating dispatched product to received product
  updateDisp(productOrdId: string, productOrdStatus: string): Observable<OrderedItem[]> {

    return this.http.get<OrderedItem[]>(this.baseUrl + "185684/updateDispatchedProducts/" + productOrdId + '/' + productOrdStatus);
  }

  updateProduct(productOrdId: string, productOrdStatus: string): Observable<OrderedItem[]> {

    return this.http.get<OrderedItem[]>(this.baseUrl + "185684/updateProduct/" + productOrdId + '/' + productOrdStatus);
  }






  showEmailLog(): Observable<Email[]> {
    console.log("http://localhost:8082/ecommerce/185755/showEmail")
    return this.http.get<Email[]>("http://localhost:8082/ecommerce/185755/showEmail")
  }
  showInventory(merchantId): Observable<Product[]> {
    return this.http.get<Product[]>("http://localhost:8082/api/prodcuts/" + merchantId);
  }

  refund(id): Observable<number> {
    console.log("http://localhost:8082//ecommerce/185756/refundMoney/" + id);
    return this.http.get<number>("http://localhost:8082//ecommerce/185756/refundMoney/" + id);
  }

}
