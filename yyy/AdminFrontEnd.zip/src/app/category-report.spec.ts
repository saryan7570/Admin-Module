import { CategoryReport } from './category-report';

describe('CategoryReport', () => {
  it('should create an instance', () => {
    expect(new CategoryReport()).toBeTruthy();
  });
});
