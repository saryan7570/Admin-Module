export class CategoryReport {

    productCategory: String;
    units: number;

    constructor() {

    }

}
