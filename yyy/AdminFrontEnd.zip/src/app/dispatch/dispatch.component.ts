import { Component, OnInit, ɵConsole } from '@angular/core';
import * as Highcharts from 'highcharts';
import { BusinessService } from '../business.service';
import { OrderedItem } from '../ordered-item';
import { AdminServiceService } from '../admin-service.service';

@Component({
   selector: 'app-dispatch',
   templateUrl: './dispatch.component.html',
   styleUrls: ['./dispatch.component.css']
})
export class DispatchComponent implements OnInit {
   orderedList = new Array<OrderedItem>();
   mobileCount: number = 0;
   laptopCount: number = 0;
   tvCount: number = 0;
   totalSales: number = 0;
   totalRevenue: number = 0;
   homeAppliances: number = 0;
   ifChartDataAvailable = false
   highcharts = Highcharts;
   chartOptions = {
      chart: {
         type: "bar"
      },
      title: {
         text: "Monthly Sales"
      },
      subtitle: {
         // text: "Source: WorldClimate.com"
      },
      xAxis: {
         categories: ["Mobile", "Laptop", "TV", "HOME APPLIANCES"]
      },
      yAxis: {
         title: {
            text: "Sales"
         }
      },
      tooltip: {
         // valueSuffix:" °C"
      },
      series: [
         {
            name: "Total Sales",
            data: [this.mobileCount,this.laptopCount,this.tvCount,this.homeAppliances]
         }

      ]
   };

   constructor(private businessService: AdminServiceService) {
      console.log("from constructor")

   }


   ngOnInit() {
      console.log("from init")
      
      this.businessService.displayOrderedItems().subscribe((businesslist) => {
         this.orderedList = (businesslist);
         console.log(this.orderedList)
         businesslist.forEach(business => {
            this.totalSales = this.totalSales + 1;
            if (business.ordStatus === "Rec") {
               this.totalSales = this.totalSales + 1;
            }
            if (business.product.prodCategory === "MOBILE") {
               this.mobileCount = this.mobileCount + 1;
            }
            else if (business.product.prodCategory === "LAPTOP") {
               this.laptopCount = this.laptopCount + 1;
            }
            else if (business.product.prodCategory === "TV") {
               this.tvCount = this.tvCount + 1;
            }
            else if (business.product.prodCategory === "HOME APPLIANCES") {
               this.homeAppliances = this.homeAppliances + 1;
            }
            
         

         });
         this.chartOptions.series = [
            {
               name: "Total Sales",
               data: [this.mobileCount,this.laptopCount,this.tvCount,this.homeAppliances]
            }
   
         ]
         this.ifChartDataAvailable = true
    
         console.log(this.chartOptions.series)
      });

      


   }
}




