import { Component, OnInit } from '@angular/core';
import { AdminServiceService } from '../admin-service.service';

@Component({
  selector: 'app-remove-merchant',
  templateUrl: './remove-merchant.component.html',
  styleUrls: ['./remove-merchant.component.css']
})
export class RemoveMerchantComponent implements OnInit {

  constructor(private adminService: AdminServiceService) { }

  ngOnInit() {
  }
  removeMerchant(merId:string): void {
    console.log(merId);
    this.adminService.deleteMerchant(merId)
    .subscribe();
      
    
}

}
