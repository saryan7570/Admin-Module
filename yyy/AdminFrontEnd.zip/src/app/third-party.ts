export class ThirdParty {

    tpName:string;
    emailId:string;
    isJoined: string;

    constructor(name:string,email:string){
        this.tpName=name,
        this.emailId=email,
        this.isJoined="false"
    }
}
