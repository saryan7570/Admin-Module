import { Component, OnInit } from '@angular/core';
import { Merchant } from '../Merchant';
import { AdminServiceService } from '../admin-service.service';
import { ThirdParty } from '../third-party';

@Component({
  selector: 'app-tpmerchantsignup',
  templateUrl: './tpmerchantsignup.component.html',
  styleUrls: ['./tpmerchantsignup.component.css']
})
export class TpmerchantsignupComponent implements OnInit {

  merchant: Merchant;
  tpmerchant: ThirdParty;
  constructor(private adminService: AdminServiceService) { }
  message: String;

  ngOnInit() {
  }

  addTPMerchant(fname, lname, email, pan, password, address, phone) {


    this.merchant = new Merchant();
    this.merchant.address = address;
    this.merchant.emailId = email;
    this.merchant.panCard = pan;
    this.merchant.firstName = fname;
    this.merchant.lastName = lname;
    this.merchant.phoneNo = phone;
    // if (this.adminService.getFromAdminDD) {
    //   this.merchant.isValid = "ACCEPTED";
    //   this.merchant.merType = "DD"
    // }
     if (this.adminService.getFromAdminTP) {
      this.merchant.isValid = "ACCEPTED";
      this.merchant.merType = "TP"
    }
    else {
      this.merchant.isValid = "PENDING";
      this.merchant.merType = "DD"
    }
    console.log(this.merchant);
    this.adminService.addTPMerchant(this.merchant, password).subscribe();
  }

}
