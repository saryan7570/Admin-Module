package com.cg.plp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.plp.entities.CategoryReport;
import com.cg.plp.entities.Merchant;
import com.cg.plp.entities.MerchantReport;
import com.cg.plp.entities.Report;
import com.cg.plp.service.AnalysisService;

@RestController
@CrossOrigin(origins = "*")
public class AnalysisController {

	@Autowired
	AnalysisService analysisService;

	@PostMapping("/add")
	public List<Merchant> add() {
		return analysisService.add();
	}
	
	@GetMapping("/getTotalRevenue")
	public double getTotalRevenueDates() {
		return analysisService.getTotalRevenue();
	}
	
	@GetMapping("/getReport")
	public List<Report> getReport() {
		return analysisService.getReport();
	}
	
	@GetMapping("/getCategoryReport")
	public List<CategoryReport> getCategoryReport() {
		return analysisService.getCategoryReport();
	}
	
	@GetMapping("/getMerchantReport")
	public List<MerchantReport> getMerchantReport() {
		return analysisService.getMerchantReport();
	}

}
