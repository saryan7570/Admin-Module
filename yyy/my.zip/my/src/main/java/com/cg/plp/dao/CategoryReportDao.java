package com.cg.plp.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.plp.entities.CategoryReport;

public interface CategoryReportDao extends JpaRepository<CategoryReport, Integer> {

}
