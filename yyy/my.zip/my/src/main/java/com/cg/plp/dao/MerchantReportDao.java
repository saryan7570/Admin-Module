package com.cg.plp.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.plp.entities.MerchantReport;

public interface MerchantReportDao extends JpaRepository<MerchantReport, Integer> {

}
