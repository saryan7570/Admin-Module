package com.cg.plp.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.plp.entities.Report;

public interface ReportDao extends JpaRepository<Report, Integer>{

}
