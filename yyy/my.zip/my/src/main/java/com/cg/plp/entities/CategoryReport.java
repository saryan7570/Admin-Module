package com.cg.plp.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class CategoryReport {

	@Id
	private int id;

	@Column
	private String productCategory;

	@Column
	private int units;

	public CategoryReport() {
		super();
	}

	public CategoryReport(int id, String productCategory, int units) {
		super();
		this.id = id;
		this.productCategory = productCategory;
		this.units = units;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getProductCategory() {
		return productCategory;
	}

	public void setProductCategory(String productCategory) {
		this.productCategory = productCategory;
	}

	public int getUnits() {
		return units;
	}

	public void setUnits(int units) {
		this.units = units;
	}

}
