package com.cg.plp.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class MerchantReport {

	@Id
	private int id;
	
	@Column
	private String merchantName;
	
	@Column
	private int units;

	public MerchantReport() {
		super();
	}

	public MerchantReport(int id, String merchantName, int units) {
		super();
		this.id = id;
		this.merchantName = merchantName;
		this.units = units;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getMerchantName() {
		return merchantName;
	}

	public void setMerchantName(String merchantName) {
		this.merchantName = merchantName;
	}

	public int getUnits() {
		return units;
	}

	public void setUnits(int units) {
		this.units = units;
	}

}
