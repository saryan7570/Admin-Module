package com.cg.plp.entities;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
public class Orders {

	@Id
//	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;

	@JoinColumn(name = "name")
	private String customerName;

	@JoinColumn(name = "productName")
	private String productName;

	@JoinColumn(name = "status")
	private String productStatus;

	@JoinColumn(name = "name")
	private String merchantName;

	@JoinColumn(name = "productTotal")
	private double orderPrice;

	@Column
	@JsonFormat(pattern = "dd-MMM-yy")
	private Date orderDate;

	public Orders() {
		super();
	}

	public Orders(int id, String customerName, String productName, String productStatus, String merchantName,
			double orderPrice, Date orderDate) {
		super();
		this.id = id;
		this.customerName = customerName;
		this.productName = productName;
		this.productStatus = productStatus;
		this.merchantName = merchantName;
		this.orderPrice = orderPrice;
		this.orderDate = orderDate;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getProductStatus() {
		return productStatus;
	}

	public void setProductStatus(String productStatus) {
		this.productStatus = productStatus;
	}

	public String getMerchantName() {
		return merchantName;
	}

	public void setMerchantName(String merchantName) {
		this.merchantName = merchantName;
	}

	public double getOrderPrice() {
		return orderPrice;
	}

	public void setOrderPrice(double orderPrice) {
		this.orderPrice = orderPrice;
	}

	public Date getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}

}
