package com.cg.plp.entities;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;

@Entity
public class Report {
	
	@Id
	private int id;

	@JoinColumn(name = "id")
	private int orderId;

	@JoinColumn(name = "productId")
	private int productId;

	@JoinColumn(name = "productCategory")
	private String productCategory;

	@JoinColumn(name = "email")
	private String merchantId;

	@JoinColumn(name = "productStatus")
	private String orderStatus;

	public Report() {
		super();
	}

	public Report(int orderId, int productId, String productCategory, String merchantId, String orderStatus) {
		super();
		this.orderId = orderId;
		this.productId = productId;
		this.productCategory = productCategory;
		this.merchantId = merchantId;
		this.orderStatus = orderStatus;
	}

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public String getProductCategory() {
		return productCategory;
	}

	public void setProductCategory(String productCategory) {
		this.productCategory = productCategory;
	}

	public String getMerchantId() {
		return merchantId;
	}

	public void setMerchantId(String merchantId) {
		this.merchantId = merchantId;
	}

	public String getOrderStatus() {
		return orderStatus;
	}

	public void setOrderStatus(String orderStatus) {
		this.orderStatus = orderStatus;
	}

}
