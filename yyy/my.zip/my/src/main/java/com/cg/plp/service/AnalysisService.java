package com.cg.plp.service;

import java.util.List;

import com.cg.plp.entities.CategoryReport;
import com.cg.plp.entities.Merchant;
import com.cg.plp.entities.MerchantReport;
import com.cg.plp.entities.Report;

public interface AnalysisService {

	public List<Merchant> add();
	
	public double getTotalRevenue();
	
	public List<Report> getReport();

	public List<CategoryReport> getCategoryReport();

	public List<MerchantReport> getMerchantReport();

}
