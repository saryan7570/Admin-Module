package com.cg.plp.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.plp.dao.CategoryReportDao;
import com.cg.plp.dao.CustomerDao;
import com.cg.plp.dao.MerchantDao;
import com.cg.plp.dao.MerchantReportDao;
import com.cg.plp.dao.OrderDao;
import com.cg.plp.dao.ReportDao;
import com.cg.plp.entities.CategoryReport;
import com.cg.plp.entities.Customer;
import com.cg.plp.entities.Merchant;
import com.cg.plp.entities.MerchantReport;
import com.cg.plp.entities.Orders;
import com.cg.plp.entities.Product;
import com.cg.plp.entities.Report;

@Service
public class AnalysisServiceImpl implements AnalysisService {

//	Date date;
	Date date;

	@Autowired
	MerchantDao merchantDao;

	@Autowired
	CustomerDao customerDao;

	@Autowired
	OrderDao orderDao;

	@Autowired
	ReportDao reportDao;

	@Autowired
	MerchantReportDao merchantReportDao;

	@Autowired
	CategoryReportDao categoryReportDao;

	@Override
	public List<Merchant> add() {

		// New Customer
		Customer customer = new Customer("ankit7570@gmail.com", "Ankit", "8937011919", "Dehradun", "ankit123", "M");
		customerDao.save(customer);

		// New Product
		date = new Date();
//		date = LocalDate.now();
		Product product = new Product(101, "Galaxy", 1000, 1, "Mobile", 1000, "Delivered", date);
		List<Product> products = new ArrayList<Product>();
		products.add(product);

		// New Merchant with Product
		Merchant merchant = new Merchant("MERC_00001", "Ritu Bisht", "111", products);
		merchantDao.save(merchant);

		// New Order
//		date = LocalDate.now();
		Orders order = new Orders(1, "Ankit", "Galaxy", "Delivered", "Nitin", 1000, date);
		orderDao.save(order);

		Report report = new Report(1, 101, "Mobile", "MERC_00001", "Delivered");
		reportDao.save(report);

		MerchantReport merchantReport = new MerchantReport(1, "Ritu Bisht", 1);
		merchantReportDao.save(merchantReport);

		CategoryReport categoryReport = new CategoryReport(1, "Mobile", 1);
		categoryReportDao.save(categoryReport);

		return merchantDao.findAll();
	}

	@Override
	public double getTotalRevenue() {
		add();
		return orderDao.getTotalRevenue();
	}

	@Override
	public List<Report> getReport() {
		return reportDao.findAll();
	}

	@Override
	public List<CategoryReport> getCategoryReport() {
		return categoryReportDao.findAll();
	}

	@Override
	public List<MerchantReport> getMerchantReport() {
		return merchantReportDao.findAll();
	}

}
