package com.cg.plp.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.plp.dao.CustomerDao;
import com.cg.plp.entities.Customer;

@Service
public class CustomerServiceImpl {
	
	@Autowired
	CustomerDao customerDao;

	public void add(Customer customer) {
		customerDao.save(customer);
	}
	
}
