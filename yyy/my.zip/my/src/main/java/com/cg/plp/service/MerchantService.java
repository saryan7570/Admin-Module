package com.cg.plp.service;

public interface MerchantService {

}
