package com.cg.plp.service;

import org.springframework.stereotype.Service;

@Service
public class OrderServiceImpl implements OrderService {

}
